//
//  Room.m
//  AV Technician Toolkit
//
//  Created by AV Programmer on 3/22/14.
//  Copyright (c) 2014 AV Services. All rights reserved.
//

#import "Room.h"

@implementation Room

@synthesize roomNum = _roomNum;
@synthesize building = _building;
@synthesize type = _type;

@end
