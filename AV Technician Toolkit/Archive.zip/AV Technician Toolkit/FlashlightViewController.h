//
//  FlashlightViewController.h
//  AV Technician Toolkit
//
//  Created by AV Programmer on 3/20/14.
//  Copyright (c) 2014 AV Services. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FlashlightViewController : UIViewController

@end
