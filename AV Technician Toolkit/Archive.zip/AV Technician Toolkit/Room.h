//
//  Room.h
//  AV Technician Toolkit
//
//  Created by AV Programmer on 3/22/14.
//  Copyright (c) 2014 AV Services. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Room : NSObject

@property (nonatomic, retain) NSString *roomNum;
@property (nonatomic, retain) NSString *building;
@property (nonatomic, retain) NSString *type;

@end
