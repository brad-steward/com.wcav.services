//
//  FirstViewController.m
//  AV Technician Toolkit
//
//  Created by AV Programmer on 3/11/14.
//  Copyright (c) 2014 AV Services. All rights reserved.
//

#import "FirstViewController.h"

@interface FirstViewController ()

@end

@implementation FirstViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	NSLog(@"Hello, World!");
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
