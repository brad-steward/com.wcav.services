//
//  main.m
//  AV Technician Toolkit
//
//  Created by AV Programmer on 3/11/14.
//  Copyright (c) 2014 AV Services. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

#import "TroubleGuideTableViewController.h"

int main(int argc, char * argv[])
{
    TroubleGuideTableViewController *viewController;
    
    NSLog(@"Hello, World!");
    NSLog(@"How are you doing today?");
    
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
    
    NSString *demoURL = @"file://localhost/Users/avprogrammer/com.wcav.services/AV Technician Toolkit/AV Technician Toolkit/demoCSV.csv";
    NSURL *temp = [NSURL URLWithString:demoURL];temp;
    if (temp != nil && [temp isFileURL]) {
        [viewController handleOpenURL:temp];
    }
    NSLog([temp path]);
}
